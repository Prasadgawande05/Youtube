import 'package:flutter/material.dart';

class AppColor {
  static const Color primarycolor = Color(0xffff0001);
  static const Color secoundrycolor = Colors.black;
  static const Color subtextcolor = Colors.grey;
}
