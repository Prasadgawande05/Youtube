class BaseUrl {
  static const String baseurl = "https://krushimahostav.yuvapsvs.com";

  static const String loginUrl =
      "https://krushimahostav.yuvapsvs.com/api/auth/login";
}
