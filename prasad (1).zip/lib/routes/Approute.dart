class AppRoutes {
  static const String firstscreen = '/';
  static const String login = "/loginscren";
  static const String shorts = "/shorts";
  static const String tabs = "/tabs";
  static const String forgotpassword = "/forgot_Password";
  static const String library = "/library_screen";
  static const String notifications = "/Notification_screen";
  static const String subscriptions = "/Subscription";
  static const String creatNewAccountScreen = "/creat_new_account";
  static const String youtubeScreen = "/youtube_screen";
  static const String youtubePlayVideo = "/YoutubePlayVideo";
}
